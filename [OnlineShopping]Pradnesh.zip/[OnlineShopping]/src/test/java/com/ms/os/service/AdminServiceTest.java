package com.ms.os.service;


import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.ms.os.entity.Category;
import com.ms.os.entity.Product;
import com.ms.os.repository.AdminRepository;

@SpringBootTest(classes= {AdminServiceTest.class})
class AdminServiceTest 
{
	
	
	
	@Mock
	AdminRepository  adminRepository;
	
	@InjectMocks
	AdminServiceImpl adminServiceImpl;
	
	public List<Category> myCatList;
		
	
	
	
	@Test
	@Order(1)
	public void testgetCategory() {
		
		//my own data considering db failed
		List<Product> p=new ArrayList<>();
		p.add(new Product(1,25000.0,"TV"));
		p.add(new Product(2,15000.0,"Mobile"));
		
		List<Category> myCatList=new ArrayList<>();
		myCatList.add(new Category(1,"Electronics",p));
		
		//will be called getCategory 
		when(adminRepository.findAll()).thenReturn(myCatList);
		
		//adminServiceImpl.getCategory();
		Assertions.assertEquals(1, adminServiceImpl.getCategory().size());
	}

}
