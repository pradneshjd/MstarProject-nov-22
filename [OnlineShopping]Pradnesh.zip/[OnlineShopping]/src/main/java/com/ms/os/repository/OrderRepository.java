package com.ms.os.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ms.os.entity.Orders;

public interface OrderRepository extends JpaRepository<Orders, Integer> {

}
