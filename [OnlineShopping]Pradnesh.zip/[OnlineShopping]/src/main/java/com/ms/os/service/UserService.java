package com.ms.os.service;



import com.ms.os.entity.User;

public interface UserService {

	User getUserId(int U_Id);

	User getUser(String U_Email,String U_Password);

	void addUser(User user);

	User updateUserProfile(int uid, User user);


	public void OrderProductById(int productid,int userid);
	
}
