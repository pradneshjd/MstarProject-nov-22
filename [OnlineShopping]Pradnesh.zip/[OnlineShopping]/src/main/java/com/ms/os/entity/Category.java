package com.ms.os.entity;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

@Entity
@Table(name = "categories")
public class Category {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int Cat_Id;
	
	private String Cat_Name;

	@OneToMany(mappedBy = "category", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JsonManagedReference
	private List<Product> product;

	public Category()
	{
		
	}
	


	public Category(int cat_Id, String cat_Name, List<Product> product) {
		super();
		Cat_Id = cat_Id;
		Cat_Name = cat_Name;
		this.product = product;
	}



	public int getCat_Id() {
		return Cat_Id;
	}

	
	public void setCat_Id(int cat_Id) {
		Cat_Id = cat_Id;
	}


	public String getCat_Name() {
		return Cat_Name;
	}

	public void setCat_Name(String cat_Name) {
		Cat_Name = cat_Name;
	}

	public List<Product> getProduct() {
		return product;
	}

	public void setProduct(List<Product> product) {
		this.product = product;
	}

	@Override
	public String toString() {
		return "Category [Cat_Id=" + Cat_Id + ", Cat_Name=" + Cat_Name + ", product=" + product + "]";
	}

}
