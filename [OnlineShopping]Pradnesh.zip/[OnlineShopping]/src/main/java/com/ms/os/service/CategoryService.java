package com.ms.os.service;

import java.util.List;

import com.ms.os.entity.Category;

public interface CategoryService {

	List<Category> getCategory();
	
	Category getCategoryId(int id);
	
	Category addCategory(Category category);
}