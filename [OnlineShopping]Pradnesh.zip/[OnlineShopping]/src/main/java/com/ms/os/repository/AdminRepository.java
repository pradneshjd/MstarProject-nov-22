package com.ms.os.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ms.os.entity.Category;
import com.ms.os.entity.Product;

@Repository

public interface AdminRepository extends JpaRepository<Category, Integer> {

	Product save(Product p);

	Category save(Category c);
	
	
	@Query(value = "select * from categories", nativeQuery = true)
	List<Category> findAll();

	@Query(value = "select * from categories where Cat_Id= :id", nativeQuery = true)
	Category findById(@Param("id") int id);

	void deleteById(int id);
}
