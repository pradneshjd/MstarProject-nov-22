package com.ms.os.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.ms.os.dto.LoginRequest;

import com.ms.os.entity.User;
import com.ms.os.service.UserService;

import jakarta.validation.Valid;





@RestController
@RequestMapping("Users")
public class UserController {
	@Autowired
	UserService userService;
	
	
	//Method for register new User
	@PostMapping("/signup")
	public @ResponseBody User addUser(@Valid @RequestBody User user)
	{
		userService.addUser(user);
		return user;
	}
	
	//Method for login
	@PostMapping("/signin")
	public ResponseEntity<?> authenticateUser(@RequestBody LoginRequest request) {
		System.out.println("in authenticate User" + request.getU_Email());
		// String email=request.getU_Email();
		User user = userService.getUser(request.getU_Email(), request.getU_Password());
		return new ResponseEntity<>(user, HttpStatus.OK);
	}
	
	
	//Method for view UserDetails by Id
	@GetMapping(value = "/Id/{U_Id}")
	public User getUserById(@PathVariable int U_Id) {
		User u = userService.getUserId(U_Id);
		return u;
	}
	
	
	//Method to edit profile
	@PutMapping("/edit_profile")
	public ResponseEntity<?>updateUserProfile(@RequestParam int uid, @RequestBody User user)
	{
		System.out.println("inside update user profile(Controller method) " + user);
	    userService.updateUserProfile(uid, user);
		return new ResponseEntity<>("User Profile Updated...!!!",HttpStatus.OK);	
	}
	
	//Method to place the order
	@PostMapping("/Order")
	public void OrderProductById(@RequestParam int productid,@RequestParam int userid)
	{
		userService.OrderProductById(productid, userid);
	}
	
	  //Getting the exception for validation
	  @ResponseStatus(HttpStatus.BAD_REQUEST)
      @ExceptionHandler(MethodArgumentNotValidException.class)
	    public Map<String, String> handleMethodArgumentNotValid(MethodArgumentNotValidException ex) 
	    {
	        Map<String, String> errors = new HashMap<>();

	        ex.getBindingResult().getFieldErrors().forEach(error ->
	                errors.put(error.getField(), error.getDefaultMessage()));

	        return errors;
	    }
	
}