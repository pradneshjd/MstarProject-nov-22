package com.ms.os.exception;



import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;



@ControllerAdvice
public class GlobalExceptionHandler {

    @Value(value = "${data.exception.message1}")
    private String message1;
    @Value(value = "${data.exception.message2}")
    private String message2;

    
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Map<String, String> handleMethodArgumentNotValid(MethodArgumentNotValidException ex) 
    {
        Map<String, String> errors = new HashMap<>();

        ex.getBindingResult().getFieldErrors().forEach(error ->
                errors.put(error.getField(), error.getDefaultMessage()));

        return errors;
    }
    
   @ExceptionHandler(value = ProductNotFoundException.class)
    public ResponseEntity<String> ProductNotFoundException(ProductNotFoundException productNotFoundException) {
        return new ResponseEntity<String>(message1, HttpStatus.NOT_FOUND);
    }
    
    @ExceptionHandler(value = Exception.class)
    public ResponseEntity<String> Exception(ProductNotFoundException productNotFoundException) {
        return new ResponseEntity<String>(message2, HttpStatus.INTERNAL_SERVER_ERROR);
    }



}