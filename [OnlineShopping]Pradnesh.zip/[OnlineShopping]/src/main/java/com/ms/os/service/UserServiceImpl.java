package com.ms.os.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

//import com.ms.os.entity.Order;
import com.ms.os.entity.Orders;
import com.ms.os.entity.Product;
import com.ms.os.entity.Role;
import com.ms.os.entity.User;
import com.ms.os.repository.OrderRepository;
import com.ms.os.repository.ProductRepository;
import com.ms.os.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {
	@Autowired
	UserRepository userRepository;
	
	@Autowired
	ProductRepository productRepository;
	
	@Autowired
	OrderRepository orderRepository;
	

	
	@Override
	public void addUser(User user) {
		userRepository.save(user);
	}

	@Override
	public User getUserId(int U_Id) {
		return userRepository.findById(U_Id);
	}
	
	@Override
	public User getUser(String email, String password)
	{
		return userRepository.findUser(email, password);
	}


	@Override
	public User updateUserProfile(int userId, User user) {

		User userd = userRepository.findById(userId);
		System.out.println("User details from "+userd);
		
		if(user.getU_Username()!=null)
		{
		userd.setU_Username(user.getU_Username());
		}else if(user.getU_Password()!=null)
		{
		userd.setU_Password(user.getU_Password());
		}
		else if(user.getU_Mobile()!=0)
		{
		userd.setU_Mobile(user.getU_Mobile());
		}
        userRepository.save(userd);
		return userd;
	}
	
	public void OrderProductById(int productid,int userid)
	{
		Product orderproduct = productRepository.findById(productid).get();
		User newuser = userRepository.findById(userid);
		
		Orders order=new Orders();
		order.setProduct(orderproduct);
		order.setUser(newuser);	
		order.setQuantity(1);
		order.setTotalprice(orderproduct.getPrice());
		
		orderRepository.save(order);
	}

}
