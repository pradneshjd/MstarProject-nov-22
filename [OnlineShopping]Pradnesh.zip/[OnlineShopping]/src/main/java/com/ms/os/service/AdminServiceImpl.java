package com.ms.os.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ms.os.entity.Category;
import com.ms.os.entity.Product;
import com.ms.os.entity.User;
import com.ms.os.exception.ProductNotFoundException;
import com.ms.os.repository.AdminRepository;
//import com.ms.os.repository.CategoryRepository;
import com.ms.os.repository.UserRepository;

@Service
public class AdminServiceImpl implements AdminService
{
	@Autowired
	AdminRepository adminRepository;
	
	@Autowired
	UserRepository userRepository;

	@Override
	public List<Category> getCategory() {
		// TODO Auto-generated method stub
		return adminRepository.findAll();
		
	}
	
	@Override
    public List<User> getAllUserDetails() {
        List<User> uList = userRepository.findAll();
        return uList;
    }
	
	
	@Override
	public Category getCategoryId(int id) throws ProductNotFoundException {
		
	   Category c= adminRepository.findById(id);
	   if(c!=null)
		   return c;
	   else
		   throw new ProductNotFoundException();
	}
	@Override
	public void addProduct(Product product)
	{
		adminRepository.save(product);
	}
	@Override
	public Category addCategory(Category category) 
	{
		return adminRepository.save(category);
	}
	@Override
	public void deleteCategoryById(int id)
	{
		adminRepository.deleteById(id);
	}
}
