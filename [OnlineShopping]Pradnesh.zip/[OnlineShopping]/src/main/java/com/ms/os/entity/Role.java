package com.ms.os.entity;

public enum Role {
	USER, ADMIN
}