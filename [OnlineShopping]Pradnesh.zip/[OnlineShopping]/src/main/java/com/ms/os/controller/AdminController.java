package com.ms.os.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ms.os.entity.Category;
import com.ms.os.exception.ProductNotFoundException;
import com.ms.os.service.AdminService;

@RestController
@RequestMapping("Admin")
public class AdminController {

	private static Logger LOGGER = LoggerFactory.getLogger(AdminController.class); //logging the data into the file
	
	@Autowired
	AdminService adminService;

	//Admin can view all products
	@GetMapping("/categories/get")
	public ResponseEntity<List<Category>> showProducts() {
		LOGGER.info("Categories were viewed by Admin");
		return new ResponseEntity<List<Category>>(adminService.getCategory(), HttpStatus.OK);
	}

	//Admin can view products by id
	@GetMapping("/categories/{pid}")
	public ResponseEntity<Category> getPro(@PathVariable int pid) throws ProductNotFoundException 
	{
		Category p = adminService.getCategoryId(pid);
			return new ResponseEntity<Category>(p, HttpStatus.OK);
	}
	
	//Admin can view all users
	@GetMapping("/getallusers")
    public ResponseEntity<?> getAllUserDetails() {
        return new ResponseEntity<>(adminService.getAllUserDetails(), HttpStatus.OK);
    }
	
    //Admin can add the products
	@PostMapping("/categories/add")
	public ResponseEntity<Category> addCategory(@RequestBody Category category) {
		
		adminService.addCategory(category);
		LOGGER.info("Admin inserted new Product!!");
		return new ResponseEntity<Category>(adminService.addCategory(category), HttpStatus.CREATED);

	}
    
	//Admin can delete product by id
	@DeleteMapping("/categories/{id}")
	public ResponseEntity<String> deleteCategoryByName(@PathVariable int id) {
		LOGGER.info("Admin deleted the category"+"Category Id"+id);
		adminService.deleteCategoryById(id);
		return ResponseEntity.status(HttpStatus.OK).body("Data deleted Successfully");
	}
	
	
}