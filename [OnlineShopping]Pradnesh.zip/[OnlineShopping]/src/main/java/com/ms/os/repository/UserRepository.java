package com.ms.os.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ms.os.entity.Role;
import com.ms.os.entity.User;


@Repository
public interface UserRepository extends JpaRepository<User,Integer>
{
	User save(User u);
	
	List<User> findAll();
	
	
	@Query(value = "select * from Users where u_Id= :id", nativeQuery = true)
	User findById(@Param("id") int id);
	
	@Query(value="select * from Users where U_Username=:u_Username", nativeQuery=true)
	User findByName(@Param("u_Username")String u_Username);
	
	@Query(value="select * from users where U_Email=:username and U_Password=:password",nativeQuery=true)
	User findUser(@Param("username")String username,@Param("password")String password);
	
	
	 @Query(value="select * from users where role like %:ADMIN%",nativeQuery = true)
	 List<User> findByRole(@Param("ADMIN") Role ADMIN);
	
}
