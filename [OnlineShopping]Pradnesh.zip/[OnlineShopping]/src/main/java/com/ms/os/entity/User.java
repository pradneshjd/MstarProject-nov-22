package com.ms.os.entity;

import java.util.List;


import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;

@Entity
@Table(name = "Users")
public class User {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer U_Id;

	private String U_First_Name;
	
	
	@NotBlank(message = "Please Enter Last Name")
	private String U_Last_Name;

    @Pattern(regexp=".+@.+\\.[a-z]+", message = "{Invalid Email Address}")
	private String U_Email;

	//@NotBlank(message = "Please Enter UserName")
	private String U_Username;
	
	
	private String U_Password;

	private long U_Mobile;

	@Enumerated(EnumType.STRING)
	private Role role;

	@OneToMany(mappedBy = "user", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JsonManagedReference
	private List<Address> address;

	public Integer getU_Id() {
		return U_Id;
	}

	public void setU_Id(int U_Id) {
		this.U_Id = U_Id;
	}

	public String getU_First_Name() {
		return this.U_First_Name;
	}

	public void setU_First_Name(String U_First_Name) {
		this.U_First_Name = U_First_Name;
	}

	public String getU_Last_Name() {
		return this.U_Last_Name;
	}

	public void setU_Last_Name(String U_Last_Name) {
		this.U_Last_Name = U_Last_Name;
	}

	public String getU_Email() {
		return this.U_Email;
	}

	public void setU_Email(String U_Email) {
		this.U_Email = U_Email;
	}

	public String getU_Username() {
		return U_Username;
	}

	public void setU_Username(String U_Username) {
		this.U_Username = U_Username;
	}

	public String getU_Password() {
		return U_Password;
	}

	public void setU_Password(String U_Password) {
		this.U_Password = U_Password;
	}

	public long getU_Mobile() {
		return this.U_Mobile;
	}

	public void setU_Mobile(long U_Mobile) {
		this.U_Mobile = U_Mobile;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public void setU_Id(Integer u_Id) {
		U_Id = u_Id;
	}
	
	
	public List<Address> getAddress() {
		return address;
	}

	public void setAddress(List<Address> address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "User [U_Id=" + U_Id + ", U_First_Name=" + U_First_Name + ", U_Last_Name=" + U_Last_Name + ", U_Email="
				+ U_Email + ", U_Username=" + U_Username + ", U_Password=" + U_Password + ", U_Mobile=" + U_Mobile
				+ ", role=" + role + ", address=" + address + "]";
	}
	
	
	
}
