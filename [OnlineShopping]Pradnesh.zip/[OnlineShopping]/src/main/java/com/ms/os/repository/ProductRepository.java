package com.ms.os.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ms.os.entity.Product;
import com.ms.os.entity.User;

@Repository
public interface ProductRepository extends JpaRepository<Product,Integer>  {
	
	//@Query(value = "select * from Users where u_Id= :id", nativeQuery = true)
	//Product findById(@Param("id") int id);
}
