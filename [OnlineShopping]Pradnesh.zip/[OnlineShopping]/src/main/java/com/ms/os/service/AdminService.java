package com.ms.os.service;

import java.util.List;

import com.ms.os.entity.Category;
import com.ms.os.entity.Product;
import com.ms.os.entity.User;
import com.ms.os.exception.ProductNotFoundException;

public interface AdminService {
	
	List<Category> getCategory();
	
	void addProduct(Product p);
	
	Category addCategory(Category category);
	
	Category getCategoryId(int id) throws ProductNotFoundException;
	
	void deleteCategoryById(int id);
	
	List<User>  getAllUserDetails();
}
