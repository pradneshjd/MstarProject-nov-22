package com.ms.os.dto;

public class LoginRequest {

	private String U_Email;
	private String U_Password;

	public LoginRequest() {

	}

	public String getU_Email() {
		return U_Email;
	}

	public void setU_Email(String u_Email) {
		U_Email = u_Email;
	}

	public String getU_Password() {
		return U_Password;
	}

	public void setU_Password(String u_Password) {
		U_Password = u_Password;
	}

	@Override
	public String toString() {
		return "LoginRequest [U_Email=" + U_Email + ", U_Password=" + U_Password + "]";
	}

}
