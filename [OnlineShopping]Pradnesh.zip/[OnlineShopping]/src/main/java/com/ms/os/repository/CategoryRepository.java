package com.ms.os.repository;

import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ms.os.entity.Category;

@Repository
@Transactional
public interface CategoryRepository extends JpaRepository<Category,Integer>  {
	
	Category save(Category c);
	
	@Query(value="select cat_id,cat_name from categories " ,nativeQuery=true)
	List<Category> findByCategory();
	
	@Query(value="select * from categories where Cat_Id= :id" ,nativeQuery=true)
	Category findById(@Param("id") int id);
		
	
}
